package listaed.listas.gincana;

public class NoResult {

    private NoResult p;
    private String e;

    public NoResult(String e){
        this.e = e;
    }

    public NoResult getP() {
        return p;
    }

    public String getE() {
        return e;
    }

    public void setE(String e) {
        this.e = e;
    }

    public void setP(NoResult p) {
        this.p = p;
    }
}
